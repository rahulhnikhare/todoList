package com.todolist.todolist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.todolist.todolist.model.Task;

public interface TaskRepository extends CrudRepository<Task, Long>{
	
	Task findByTaskId(int taskId);
	
	@Modifying
    @Query("delete from Task where Task_id = ?1")
    void delete(Long entityId);
} 