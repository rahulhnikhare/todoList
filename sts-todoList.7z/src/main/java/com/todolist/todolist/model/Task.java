package com.todolist.todolist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Task")
public class Task {
	
	private static final long serialVersionUID = -3009157732242241606L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	
    @Column(name = "taskId")
	private int taskId;    
    
    public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	@Column(name = "taskName")
	private String taskName;
    
    @Column(name = "timeStamp")
	private long timeStamp;

    public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	@Column(name = "taskType")
	private String taskType;

 
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public Task(){}
	/*public Task( String taskName, long timeStamp, String taskType) {
		super();
		System.out.println("TaskName::"+taskName);
		this.taskName = taskName;
		this.timeStamp = timeStamp;
		this.taskType = taskType;
	}*/
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "TaskName:"+this.taskName + " task ID: " + this.taskId;
	}
	
}
