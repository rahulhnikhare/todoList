package com.todolist.todolist.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ResponseHelper {

    private final static String HEADER_ERROR_MESSAGE = "ErrorMessage";
    private final static String HEADER_EXCEPTION_MESSAGE = "ExceptionMessage";
    private final static String HEADER_EXCEPTION_MESSAGE_NOT_PROVIDED = "Not provided";

    public static <T> ResponseEntity<T> ok(T obj) {
        return ResponseEntity.ok(obj);
    }

    public static <T> ResponseEntity<T> ok(T obj, HttpHeaders headers) {
        return ResponseEntity.status(HttpStatus.OK).headers(headers).body(obj);
    }

    public static <T> ResponseEntity<T> error(HttpStatus httpStatus, String errorMessage, Exception exception, T obj) {
        return ResponseEntity.status(httpStatus)
                .header(HEADER_ERROR_MESSAGE, errorMessage)
                .header(HEADER_EXCEPTION_MESSAGE, exception != null ? exception.getMessage() : HEADER_EXCEPTION_MESSAGE_NOT_PROVIDED)
                .body(obj);
    }

    public static <T> ResponseEntity<T> error(HttpStatus httpStatus, String errorMessage, Exception exception) {
        return error(httpStatus, errorMessage, exception, null);
    }

    public static <T> ResponseEntity<T> error(HttpStatus httpStatus, String errorMessage) {
        return error(httpStatus, errorMessage, null);
    }
}
