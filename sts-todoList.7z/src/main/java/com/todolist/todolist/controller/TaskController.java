package com.todolist.todolist.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.todolist.todolist.model.Task;
import com.todolist.todolist.repository.TaskRepository;

@CrossOrigin(origins = "*")
@RestController
public class TaskController {
	@Autowired
	TaskRepository repository;
	
    private static Logger logger = LoggerFactory.getLogger(TaskController.class);

	
    @RequestMapping(value = "/saveTask", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	    public ResponseEntity<Boolean> process(@RequestBody Task task){
    	logger.info("client requested to SaveTask", task.toString());
    	try {
               repository.save(task);
               return ResponseHelper.ok(Boolean.TRUE);
           } catch (Exception ex) {
               return ResponseHelper.error(HttpStatus.BAD_REQUEST,"Error while Saving"+task.toString());
           }
	    }
    
    @RequestMapping(value = "/updateTask", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
    public ResponseEntity<Boolean> updateTask(@RequestBody Task task){
    	logger.info("client requested to UpdateTask of Task", task.toString());

        try {
         Task taskNew  = repository.findByTaskId(task.getTaskId());
       	 taskNew.setTaskType(task.getTaskType());
       	 repository.save(taskNew);
            return ResponseHelper.ok(Boolean.TRUE);
        } catch (Exception ex) {
            return ResponseHelper.error(HttpStatus.BAD_REQUEST,"Error while Update"+task.toString());
        }
    }
    
    @RequestMapping(path = "/deleteTask/{taskId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Boolean> deleteTaskEntity(@PathVariable("taskId") Long taskId) {
        logger.info("client requested delete of TaskEntity with id={}", taskId);

        try {
            repository.delete(taskId);
            return ResponseHelper.ok(Boolean.TRUE);
        } catch (Exception ex) {
            return ResponseHelper.error(HttpStatus.BAD_REQUEST,"Error while Delete"+taskId);
        }

    }

}
