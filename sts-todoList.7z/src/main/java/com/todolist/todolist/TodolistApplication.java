package com.todolist.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TodolistApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodolistApplication.class, args);
	   /* ApplicationContext ctx = SpringApplication.run(TodolistApplication.class, args);
	    
	    TaskRepository repository = ctx.getBean(TaskRepository.class);
	    Task person = new Task();
	    person.setTaskId(1);
	    person.setTaskName("NAME");
	    person.setTaskType("C");
	    person.setTimeStamp(12345);

	    // Create person
	    repository.save(person);*/
	}
}
